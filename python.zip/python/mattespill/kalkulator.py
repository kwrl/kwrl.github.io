print(2 + 3)
print(17 - 8)
print(3 * 4)
print(22 / 7)
