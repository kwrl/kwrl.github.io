navn = input('Hva heter du? ')
print('Hei ' + navn)
